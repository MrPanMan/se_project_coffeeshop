Triple Peaks Coffee Shop

This is the second project of the Software Engineering program at TripleTen. It was created using HTML and CSS, based on the design brief.

Project features:

- Semantic HTML5
- Flexbox
- Positioning
- Flat BEM file structure
- A custom form
- CSS animation and transform

Plan on improving the project

A menu that involves links that open up a picture of the desired product in a miniture window on the same page.
So far the coffee shop website is lacking in visuals that stimulate said cafe feeling
